<?php
/**
 * TJ & U Auto Garage child theme: a mechanical, body and paint garage on Rabai Road, Buruburu, booked like a shop.
 * Services are products priced by vehicle type (the global "Vehicle type" attribute); the cart is the booking,
 * and checkout asks for the car, garage drop-off or towing / pick-up, the date and the drop-off time.
 */

const TJ_WHATSAPP = '254790407785'; // The garage desk number on their Instagram and Google listing; WhatsApp on it is a PLACEHOLDER to confirm.
const TJ_PHONE    = '0790 407 785';
const TJ_TEL      = '+254790407785';
const TJ_PHONE2   = '0721 222 585';
const TJ_TEL2     = '+254721222585';
const TJ_EMAIL    = 'tjanduauto@gmail.com';
const TJ_IG       = 'https://www.instagram.com/tjanduauto/';
const TJ_MAPS     = 'https://maps.google.com/?cid=8457862122751536907'; // Their Google listing "Tj And U Auto Garage" (PVCF+92, -1.2790638, 36.8725757).
const TJ_HOURS    = 'Mon–Fri 7:30 am–5:30 pm · Sat 8 am–3 pm · Sun closed';
const TJ_FONTS    = 'https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,600;0,700;0,800;0,900;1,800;1,900&family=Barlow:wght@400;500;600;700&display=swap';

// Drop-off at the garage, or towing / pick-up (the brief's step 4). Pick-up areas and fees are PLACEHOLDERS.
const TJ_PLACES = [ 'garage' => 'Drop-off at our Rabai Road garage', 'pickup' => 'Request towing / pick-up' ];
const TJ_AREAS  = [
	'none'      => 'No pick-up: I\'ll drop it off',
	'buruburu'  => 'Buruburu, Uhuru Estate & Makadara',
	'umoja'     => 'Umoja, Kariobangi, Donholm & Kayole',
	'eastleigh' => 'Eastleigh, Jogoo Road & Ngara',
	'embakasi'  => 'Embakasi, Pipeline, Fedha & Utawala',
	'thika-rd'  => 'Kasarani, Roysambu & Thika Road',
	'cbd'       => 'CBD, Upper Hill & Industrial Area',
	'other'     => 'Elsewhere in Nairobi (fee quoted)',
];
const TJ_SLOTS = [ '8am' => '8:00 am', '10am' => '10:00 am', '12pm' => '12:00 noon', '2pm' => '2:00 pm', '4pm' => '4:00 pm (weekdays)' ];

// Estimator service categories (the brief's five): [ name, what it covers, [ [ service, option ] ], time, price spread ].
// The range shown runs from the service's price to price × spread, because the real cost depends on the car.
const TJ_TIERS = [
	'minor'      => [ 'Minor Service', 'Oil, filter & safety checks', [ [ 'minor-service', null ] ], '2–3 hours', 1.25 ],
	'major'      => [ 'Major Overhaul', 'Filters, plugs, fluids & full inspection', [ [ 'major-service', null ] ], '1 day', 1.4 ],
	'body'       => [ 'Body Paint / Panel Beating', 'Dents beaten out & panels repainted', [ [ 'panel-repaint', '2 panels' ] ], '1–3 days', 2 ],
	'ceramic'    => [ 'Ceramic Coating', '10H coating on freshly buffed paint', [ [ 'ceramic-coating', null ] ], '2 days', 1.2 ],
	'diagnostic' => [ 'Diagnostic Check', 'Computer scan & fault finding', [ [ 'computer-diagnostics', null ] ], '30–60 min', 1 ],
];
// Estimator add-ons: [ service, option, label ]. Vehicle-priced services follow the chosen type.
const TJ_ADDONS = [
	[ 'computer-diagnostics', null, 'Computer diagnostic check' ],
	[ 'brake-service', 'One axle', 'Brake pads fitted, one axle (labour)' ],
	[ 'body-buffing', null, 'Full body buffing & polish' ],
	[ 'headlight-restoration', null, 'Headlight restoration' ],
	[ 'rim-styling', 'Set of 4: original colour', 'Rim refurbishment, set of 4' ],
];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'tj-fonts', TJ_FONTS, [], null );
	wp_enqueue_style( 'tj', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'tj', $uri . '/assets/tj.js', [], filemtime( $dir . '/assets/tj.js' ), true );
	wp_localize_script( 'tj', 'TJ', [
		'store'    => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'     => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'checkout' => esc_url_raw( wc_get_checkout_url() ),
		'home'     => esc_url_raw( home_url( '/' ) ),
		'wa'       => TJ_WHATSAPP,
		'est'      => is_front_page() || is_page( 'estimator' ) ? tj_estimator_data() : null,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'tj-fonts', TJ_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// Vehicle pages (/vehicle/executive-suv/) need rewrite rules made after the attribute exists.
add_action( 'init', function () {
	if ( get_option( 'tj_rewrites' ) !== '1' && taxonomy_exists( 'pa_vehicle' ) ) {
		flush_rewrite_rules();
		update_option( 'tj_rewrites', '1' );
	}
}, 99 );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way businesses here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function tj_wa_link( $text = '' ) {
	return 'https://wa.me/' . TJ_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function tj_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

function tj_product( $slug ) {
	$post = get_page_by_path( $slug, OBJECT, 'product' );
	return $post ? wc_get_product( $post->ID ) : null;
}

function tj_is_quote( $product_id ) {
	return get_post_meta( $product_id, '_tj_quote', true ) === 'yes';
}

function tj_clip_url( $name ) {
	return $name ? get_stylesheet_directory_uri() . '/assets/clips/' . $name . '.mp4' : '';
}

const TJ_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

/**
 * "Label: value" lines staff type on the product screen, as label => value pairs.
 */
function tj_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_tj_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

function tj_included( $product_id ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_tj_included', true ) ) ) ) );
}

/** Names of the attributes a customer chooses on a variable product, e.g. [ 'Vehicle type', 'Protection' ]. */
function tj_choices( WC_Product $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return [];
	}
	$out = [];
	foreach ( $product->get_attributes() as $attr ) {
		if ( $attr->get_variation() ) {
			$out[] = wc_attribute_label( $attr->get_name(), $product );
		}
	}
	return $out;
}

/** Vehicle-class terms in their set order. */
function tj_vehicle_terms() {
	if ( ! taxonomy_exists( 'pa_vehicle' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'pa_vehicle', 'hide_empty' => false, 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

/**
 * The cheapest purchasable variation of a product for one vehicle class (null = any class) whose
 * options include $option (null = any option).
 */
function tj_variation_for( WC_Product $product, $size, $option = null ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return null;
	}
	$best = null;
	foreach ( $product->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		if ( ! $v || ! $v->is_purchasable() ) {
			continue;
		}
		$a = $v->get_attributes();
		if ( ( $size !== null && ( $a['pa_vehicle'] ?? '' ) !== $size ) || ( $option !== null && ! in_array( $option, $a, true ) ) ) {
			continue;
		}
		if ( ! $best || (float) $v->get_price() < (float) $best->get_price() ) {
			$best = $v;
		}
	}
	return $best;
}

/** One estimator line: a fixed price, or a price per vehicle class. */
function tj_estimator_part( WC_Product $p, $option, array $sizes ) {
	$name = html_entity_decode( $p->get_name(), ENT_QUOTES ) . ( $option ? ' (' . $option . ')' : '' );
	if ( ! $p->is_type( 'variable' ) ) {
		return [ 'name' => $name, 'id' => $p->get_id(), 'price' => (float) $p->get_price() ];
	}
	if ( ! isset( $p->get_attributes()['pa_vehicle'] ) ) {
		$v = tj_variation_for( $p, null, $option );
		return $v ? [ 'name' => $name, 'id' => $v->get_id(), 'price' => (float) $v->get_price() ] : null;
	}
	$by = [];
	foreach ( $sizes as $s ) {
		$v = tj_variation_for( $p, $s, $option );
		if ( $v ) {
			$by[ $s ] = [ 'id' => $v->get_id(), 'price' => (float) $v->get_price() ];
		}
	}
	return [ 'name' => $name, 'by' => $by ];
}

/** Prices and variation ids for the estimator, read from the services so admin price edits show up there too. */
function tj_estimator_data() {
	$sizes = [];
	foreach ( tj_vehicle_terms() as $t ) {
		$sizes[ $t->slug ] = $t->name;
	}
	$tiers = [];
	foreach ( TJ_TIERS as $key => [ $name, $sub, $parts, $time, $spread ] ) {
		$tier = [ 'name' => $name, 'sub' => $sub, 'parts' => [], 'quote' => false, 'time' => $time, 'spread' => $spread ];
		foreach ( $parts as [ $slug, $option ] ) {
			$p    = tj_product( $slug );
			$part = $p ? tj_estimator_part( $p, $option, array_keys( $sizes ) ) : null;
			if ( ! $part ) {
				continue 2;
			}
			$part['slug']     = $slug;
			$tier['parts'][]  = $part;
			$tier['quote']    = $tier['quote'] || tj_is_quote( $p->get_id() );
		}
		$tiers[ $key ] = $tier;
	}
	$addons = [];
	foreach ( TJ_ADDONS as [ $slug, $option, $label ] ) {
		$p    = tj_product( $slug );
		$part = $p && $p->is_purchasable() ? tj_estimator_part( $p, $option, array_keys( $sizes ) ) : null;
		if ( $part ) {
			$part['slug']     = $slug;
			$part['name']     = $label;
			$addons[ $slug ] = $part;
		}
	}
	return [ 'sizes' => $sizes, 'tiers' => $tiers, 'addons' => $addons, 'areas' => TJ_AREAS, 'places' => TJ_PLACES ];
}

function tj_badges_html( WC_Product $product ) {
	$time = get_post_meta( $product->get_id(), '_tj_time', true );
	$perk = get_post_meta( $product->get_id(), '_tj_perk', true );
	$h    = ( $perk ? '<span class="tj-badge tj-badge--perk">' . esc_html( $perk ) . '</span>' : '' ) . ( $time ? '<span class="tj-badge">' . esc_html( $time ) . '</span>' : '' );
	return $h ? '<div class="tj-badges">' . $h . '</div>' : '';
}

// "From KSh 12,000" instead of a price range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	return $min === $max ? $html : '<span class="tj-from">From</span> ' . wc_price( $min );
}, 10, 2 );
// The insurance assessment is booked at no charge: say so instead of WooCommerce's "Free!".
add_filter( 'woocommerce_get_price_html', fn( $html, $product ) => (float) $product->get_price() === 0.0 && $product->is_type( 'simple' ) ? '<span class="tj-free">No charge to book</span>' : $html, 10, 2 );

/** The vehicle-class page being viewed (/vehicle/executive-suv/), if any. */
function tj_current_vehicle() {
	$q = get_queried_object();
	return $q instanceof WP_Term && $q->taxonomy === 'pa_vehicle' ? $q : null;
}

add_filter( 'woocommerce_product_single_add_to_cart_text', function ( $text, $product = null ) {
	return $product instanceof WC_Product && tj_is_quote( $product->get_id() ) ? 'Book an inspection' : 'Add to my booking';
}, 10, 2 );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p || ! $p->is_in_stock() ) {
		return $t;
	}
	if ( tj_current_vehicle() && $p->is_type( 'variable' ) ) {
		return 'Book for this vehicle';
	}
	$choices = tj_choices( $p );
	return $choices ? 'Choose ' . strtolower( $choices[0] ) : 'Add to booking';
}, 10, 2 );
// On a vehicle-class page, cards open the service with that class already chosen.
add_filter( 'woocommerce_product_add_to_cart_url', function ( $url, $p ) {
	$term = tj_current_vehicle();
	return $term && $p->is_type( 'variable' ) && isset( $p->get_attributes()['pa_vehicle'] ) ? add_query_arg( 'attribute_pa_vehicle', $term->slug, $p->get_permalink() ) : $url;
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', fn( $text, $product ) => $product->is_in_stock() ? 'Taking bookings · ' . TJ_HOURS : 'Fully booked', 10, 2 );

/* -------------------------------------------------------------------------
 * Service page
 * ---------------------------------------------------------------------- */

// Benefit badges, time and key facts above the options.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$id    = $product->get_id();
	$perks = array_filter( array_map( 'trim', explode( '|', (string) get_post_meta( $id, '_tj_perks', true ) ) ) );
	$time  = get_post_meta( $id, '_tj_time', true );
	echo '<div class="tj-tags">';
	foreach ( $perks as $perk ) {
		echo '<span class="tj-tag">' . esc_html( $perk ) . '</span>';
	}
	echo ( $time ? '<span class="tj-tag tj-tag--time">' . esc_html( $time ) . '</span>' : '' ) . '</div>';
	if ( tj_is_quote( $id ) ) {
		echo '<p class="tj-note"><strong>Indicative price.</strong> Booking reserves an inspection at our Rabai Road garage; we confirm the exact price before any work starts.</p>';
	}
	$keys = array_slice( tj_specs( $id ), 0, 4, true );
	if ( $keys ) {
		echo '<ul class="tj-keyspecs">';
		foreach ( $keys as $k => $v ) {
			echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
		}
		echo '</ul>';
	}
} );

// Book on WhatsApp, the workshop clip, add-ons and promises under the button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$price = $product->is_type( 'variable' ) ? 'from ' . tj_money( $product->get_variation_price( 'min' ) ) : tj_money( $product->get_price() );
	$msg   = 'Hi TJ&U, I\'d like to book: ' . $product->get_name() . ' (' . $price . '). ' . $product->get_permalink();
	echo '<a class="tj-wa-order" data-tj-wa-product="' . esc_attr( $product->get_name() ) . '" data-tj-wa-price="' . esc_attr( $price ) . '" data-tj-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( tj_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . TJ_WA_ICON . 'Get an instant WhatsApp estimate</a>';

	$clip = get_post_meta( $product->get_id(), '_tj_clip', true );
	if ( $clip ) {
		echo '<figure class="tj-pdp-clip"><video src="' . esc_url( tj_clip_url( $clip ) ) . '" poster="' . esc_url( str_replace( '.mp4', '.webp', tj_clip_url( $clip ) ) ) . '" muted loop playsinline autoplay preload="metadata"></video><figcaption>Filmed in our Rabai Road workshop ·<a href="' . esc_url( TJ_IG ) . '" target="_blank" rel="noopener">more on Instagram</a></figcaption></figure>';
	}

	$pairs = array_filter( array_map( 'wc_get_product', $product->get_upsell_ids() ) );
	if ( $pairs ) {
		echo '<div class="tj-pairs"><p class="tj-pairs__title">Popular add-ons</p>';
		foreach ( $pairs as $p ) {
			$btn = $p->is_type( 'simple' ) && $p->is_in_stock()
				? '<button type="button" class="tj-pairs__add" data-tj-add="' . $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to your booking">+ Add</button>'
				: '<a class="tj-pairs__add" href="' . esc_url( $p->get_permalink() ) . '">View</a>';
			echo '<div class="tj-pairs__item"><a href="' . esc_url( $p->get_permalink() ) . '">' . $p->get_image( 'woocommerce_gallery_thumbnail', [ 'alt' => '' ] ) . '</a><div><a href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '</a><span>' . wp_kses_post( $p->get_price_html() ) . '</span></div>' . $btn . '</div>';
		}
		echo '</div>';
	}

	echo '<div class="tj-promise"><div><span aria-hidden="true">⚙</span><p><strong>Genuine parts, old parts shown</strong>We show you what we replaced and call before any extra work.</p></div><div><span aria-hidden="true">⌖</span><p><strong>Drop off or we tow it in</strong>Bring it to Rabai Road, Buruburu, or ask for towing / pick-up.</p></div><div><span aria-hidden="true">✓</span><p><strong>Checked before release</strong>Every car is inspected and road-tested; then you pay by M-Pesa or cash.</p></div></div>';
} );

// What's included, and booking & payment tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return $tabs;
	}
	$id       = $product->get_id();
	$specs    = tj_specs( $id );
	$included = tj_included( $id );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['title'] = 'About this service';
	}
	if ( $specs || $included ) {
		$tabs['tj_included'] = [
			'title'    => 'What\'s included',
			'priority' => 5,
			'callback' => function () use ( $specs, $included ) {
				echo '<div class="tj-sheet">';
				if ( $included ) {
					echo '<div><h3>What we do</h3><ul class="tj-checks">';
					foreach ( $included as $s ) {
						echo '<li>' . esc_html( $s ) . '</li>';
					}
					echo '</ul></div>';
				}
				echo '<div><h3>Good to know</h3><table class="tj-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table></div></div>';
			},
		];
	}
	$tabs['tj_booking'] = [
		'title'    => 'Booking & payment',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Book online:</strong> add the service, then choose garage drop-off or towing / pick-up, the date and a drop-off time at checkout. We call to confirm.</li><li><strong>Where:</strong> Rabai Road, Uhuru Estate, Buruburu Phase 1, near the Rubis petrol station (<a href="' . esc_url( TJ_MAPS ) . '" target="_blank" rel="noopener">map</a>). Towing or pick-up on request.</li><li><strong>Hours:</strong> ' . esc_html( TJ_HOURS ) . '.</li><li><strong>Pay:</strong> by M-Pesa or cash when you collect the car. Body work, resprays, coatings and upholstery take an M-Pesa deposit to book. Insurance repairs are paid by your insurer; you pay the excess.</li><li><strong>WhatsApp:</strong> prefer to chat? Send photos of your car to ' . esc_html( TJ_PHONE ) . ' for an estimate.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Service cards
 * ---------------------------------------------------------------------- */

function tj_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Hover image (first gallery photo), the video badge and the details pop-up on card images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = tj_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt     = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'tj-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$clip  = get_post_meta( $product->get_id(), '_tj_clip', true );
	$extra = ( $clip ? '<span class="tj-pov" aria-hidden="true">▶ Studio POV</span>' : '' )
		. sprintf( '<button type="button" class="tj-qv-btn" data-tj-qv="%1$d" data-tj-clip="%3$s" aria-label="Details of %2$s">%4$s</button>', $product->get_id(), esc_attr( $product->get_name() ), esc_url( tj_clip_url( $clip ) ), $clip ? 'Details &amp; video' : 'View details' );
	$pos   = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Category label above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = tj_card_product( $instance );
	$badge   = $product ? get_post_meta( $product->get_id(), '_tj_badge', true ) : '';
	return ( $badge ? '<p class="tj-card-badge">' . esc_html( $badge ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Benefit and time badges, "after inspection" on quote-led work, and on a vehicle page the price for that class.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = tj_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$term = tj_current_vehicle();
	if ( $term && $product->is_type( 'variable' ) && isset( $product->get_attributes()['pa_vehicle'] ) ) {
		$v = tj_variation_for( $product, $term->slug );
		if ( $v ) {
			$content = '<div class="wp-block-woocommerce-product-price"><div class="wc-block-components-product-price">' . ( count( tj_choices( $product ) ) > 1 ? '<span class="tj-from">From</span> ' : '' ) . wc_price( $v->get_price() ) . '</div></div>';
		}
	}
	$quote = tj_is_quote( $product->get_id() ) ? '<p class="tj-quote-note">Indicative · confirmed after inspection</p>' : '';
	return tj_badges_html( $product ) . $content . $quote;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and service lists
 * ---------------------------------------------------------------------- */

function tj_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// Service highlights: one tile per category, with the photo of its first service.
add_shortcode( 'tj_services', function () {
	$h   = '<div class="tj-services">';
	$sub = [
		'mechanical'       => 'Minor & major service · Diagnostics · Brakes · Suspension · SRS',
		'color-craft'      => 'Accident repair · Nose cuts · Panel beating · Full respray · Rust',
		'ceramic-coating'  => '10H ceramic · Full body buffing · Headlights',
		'insurance-claims' => 'Assessment · Estimate for your insurer · Approved repair',
		'interior'         => 'Seat upholstery · Dashboard & steering · Sound proofing',
		'custom-mods'      => 'Prado 150 skirting · Rim styling',
	];
	foreach ( tj_categories() as $t ) {
		$list = wc_get_products( [ 'category' => [ $t->slug ], 'limit' => 1, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
		if ( $t->slug === 'insurance-claims' ) {
			$list = array_filter( [ tj_product( 'insurance-claim-repair' ) ] );
		}
		$img = $list ? reset( $list )->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$url = $t->slug === 'insurance-claims' ? home_url( '/insurance-claims/' ) : get_term_link( $t );
		$h  .= sprintf(
			'<a class="tj-service tj-service--%s" href="%s"><span class="tj-service__img">%s</span><span class="tj-service__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_attr( $t->slug ),
			esc_url( $url ),
			$img,
			esc_html( $t->name ),
			esc_html( $sub[ $t->slug ] ?? '' )
		);
	}
	return $h . '</div>';
} );

// "Book by vehicle type": a tile per type with its minor-service price, plus fleets and trucks.
add_shortcode( 'tj_vehicles', function () {
	$service = tj_product( 'minor-service' );
	$icons   = [
		'hatchback' => 'M6 42h88M14 42V32c0-3 2-5 5-6l10-10c2-2 4-3 7-3h24c3 0 5 1 6 3l8 12 10 2c3 1 4 3 4 6v6',
		'sedan'     => 'M6 42h88M12 42v-6c0-3 2-4 5-5l9-9c2-2 4-3 7-3h26c3 0 5 1 7 3l9 8 11 2c3 1 4 3 4 6v4',
		'suv'       => 'M6 42h88M10 42V30c0-3 2-5 5-5l9-9h36c3 0 5 1 7 3l8 7h8c3 0 5 2 5 5v11',
		'4x4'       => 'M6 42h88M9 42V20c0-2 2-4 4-4h52c3 0 5 1 7 3l6 7h7c3 0 5 2 5 5v11M30 16v10M52 16v10',
		'van'       => 'M6 42h88M8 42V14c0-2 2-4 4-4h56c3 0 5 1 7 3l12 13c1 1 2 3 2 5v11M58 10v16h28',
	];
	$examples = [ 'hatchback' => 'Vitz, Fit, Note, Demio, Golf', 'sedan' => 'Premio, Axio, C-Class, E-Class, A4', 'suv' => 'CX-5, Harrier, X-Trail, Vezel, GLC', '4x4' => 'Prado, V8, LX570, Hilux, D-Max', 'van' => 'Hiace, Caravan, Noah, ToyoAce' ];
	$h = '<div class="tj-vehicles">';
	foreach ( tj_vehicle_terms() as $t ) {
		$v  = $service ? tj_variation_for( $service, $t->slug ) : null;
		$h .= sprintf(
			'<a class="tj-vehicle" href="%s"><svg viewBox="0 0 100 52" aria-hidden="true"><path d="%s"/><circle cx="28" cy="42" r="7"/><circle cx="72" cy="42" r="7"/></svg><strong>%s</strong><em>%s</em>%s</a>',
			esc_url( get_term_link( $t ) ),
			esc_attr( $icons[ $t->slug ] ?? $icons['sedan'] ),
			esc_html( $t->name ),
			esc_html( $examples[ $t->slug ] ?? '' ),
			$v ? '<span>Minor service <b>' . esc_html( tj_money( $v->get_price() ) ) . '</b></span>' : ''
		);
	}
	$h .= '<a class="tj-vehicle tj-vehicle--fleet" href="/fleet-commercial/"><svg viewBox="0 0 100 52" aria-hidden="true"><path d="M6 42h88M8 42V12c0-2 2-4 4-4h50v34M62 18h16l12 13v11"/><circle cx="24" cy="42" r="7"/><circle cx="76" cy="42" r="7"/></svg><strong>Fleets, buses &amp; trucks</strong><em>School buses, trucks &amp; company cars</em><span>Get a fleet quote →</span></a>';
	return $h . '</div>';
} );

// Category and vehicle-type chips above shop, category, vehicle and search pages.
function tj_chip( $label, $url, $on, $count = null, $small = false ) {
	return sprintf( '<a class="tj-chip%s%s" href="%s">%s%s</a>', $small ? ' tj-chip--sm' : '', $on ? ' is-on' : '', esc_url( $url ), esc_html( $label ), $count === null ? '' : ' <em>' . (int) $count . '</em>' );
}
add_shortcode( 'tj_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="tj-filters" aria-label="Filter services"><div class="tj-filters__row">';
	$h .= tj_chip( 'All services', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( tj_categories() as $t ) {
		$h .= tj_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	$h .= '</div><div class="tj-filters__row"><span>Prices for</span>';
	foreach ( tj_vehicle_terms() as $t ) {
		$h .= tj_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, null, true );
	}
	return $h . '</div></nav>';
} );

// Reviews: their Google listing (4.5 from 20 reviews) and the 5-star reviews that say something, word for word.
add_shortcode( 'tj_reviews', function () {
	$reviews = [
		[ 'Outstanding service and highly professional staff! I\'ve taken my vehicle to several insurance-approved garages before, but this one truly stands out above the rest. The level of detail and care they put into their work is exceptional. The owner is friendly, hands-on, and always available to take calls and provide timely updates.', 'Enock Wambua', 'Google review · Local Guide' ],
		[ 'Clean job and good-hearted management.', 'Grishon Ndungu', 'Google review' ],
		[ 'For all auto works with the best service… Just in time.', 'Joel Njoroge', 'Google review' ],
		[ 'Very efficient.', 'Wilfred Ngugi', 'Google review' ],
	];
	$h  = '<div class="tj-reviews"><a class="tj-reviews__score" href="' . esc_url( TJ_MAPS ) . '" target="_blank" rel="noopener"><strong>4.5</strong><span class="tj-stars" aria-label="4.5 out of 5">★★★★½</span><span>from 20 Google reviews</span><em>Read them on Google Maps →</em></a><div class="tj-reviews__list">';
	foreach ( $reviews as $i => [ $text, $who, $where ] ) {
		$h .= '<figure class="tj-review' . ( $i ? '' : ' tj-review--wide' ) . '"><span class="tj-stars" aria-label="5 out of 5">★★★★★</span><blockquote>' . esc_html( $text ) . '</blockquote><figcaption><strong>' . esc_html( $who ) . '</strong><span>' . esc_html( $where ) . '</span></figcaption></figure>';
	}
	$h .= '<div class="tj-review tj-review--promise"><strong>Our commitments</strong><ul><li><b>Transparent quotes.</b> You get the price before work starts, and we call before anything extra.</li><li><b>Parts accountability.</b> Genuine parts, and your old parts shown to you.</li><li><b>Quality check before release.</b> Every car is inspected and road-tested before we hand it back.</li></ul></div>';
	$h .= '<a class="tj-review tj-review--ig" href="' . esc_url( TJ_IG ) . '" target="_blank" rel="noopener"><strong>500+ posts of real jobs</strong><span>Every rebuild, respray and service, from day one to the drive out</span><em>@tjanduauto →</em></a>';
	return $h . '</div></div>';
} );

// Before / after sliders: frames from their own Instagram transformations. Pairs whose photos are missing are skipped.
const TJ_BEFORE_AFTER = [
	[ 'ba-crash', 'Rear-end rebuild', 'Day 1', 'Delivered', 'Mercedes GLE 350d with its rear end crushed, on day one at TJ & U', 'The same GLE rebuilt and repainted outside the garage' ],
	[ 'ba-paint', 'Factory paint restored', 'Restoring', 'Restored', 'A Prado 150 being restored on the TJ & U forecourt', 'The same Prado with its factory paint restored' ],
	[ 'ba-mech', 'Nose cut & electrical', 'Stripped', 'Rebuilt', 'Mazda CX-5 front end stripped for a nose cut', 'The same CX-5 with its new nose cut, lights and electrics working' ],
];
add_shortcode( 'tj_before_after', function () {
	$dir   = get_stylesheet_directory_uri() . '/assets/photos/';
	$pairs = array_values( array_filter( TJ_BEFORE_AFTER, fn( $p ) => file_exists( get_stylesheet_directory() . '/assets/photos/' . $p[0] . '-after.webp' ) ) );
	$h = '<div class="tj-ba-tabs" role="tablist">';
	foreach ( $pairs as $i => [ $key, $title ] ) {
		$h .= '<button type="button" role="tab" aria-selected="' . ( $i ? 'false' : 'true' ) . '" data-tj-ba-tab="' . $i . '"' . ( $i ? '' : ' class="is-on"' ) . '>' . esc_html( $title ) . '</button>';
	}
	$h .= '</div>';
	foreach ( $pairs as $i => [ $key, $title, $l, $r, $alt_before, $alt_after ] ) {
		$h .= '<figure class="tj-ba" data-tj-ba data-tj-ba-pane="' . $i . '" style="--pos:50%"' . ( $i ? ' hidden' : '' ) . '><img src="' . esc_url( $dir . $key . '-after.webp' ) . '" alt="' . esc_attr( $alt_after ) . '" width="720" height="720" loading="lazy"><div class="tj-ba__before"><img src="' . esc_url( $dir . $key . '-before.webp' ) . '" alt="' . esc_attr( $alt_before ) . '" width="720" height="720" loading="lazy"></div><span class="tj-ba__label tj-ba__label--l">' . esc_html( $l ) . '</span><span class="tj-ba__label tj-ba__label--r">' . esc_html( $r ) . '</span><span class="tj-ba__handle" aria-hidden="true"></span><input type="range" min="0" max="100" value="50" aria-label="' . esc_attr( 'Slide to compare: ' . $title ) . '"></figure>';
	}
	return '<div class="tj-ba-wrap">' . $h . '</div>';
} );

// Workshop POV: muted loops from their own reels, each linking to its service.
add_shortcode( 'tj_clips', function () {
	$clips = [
		[ 'service', 'Oil & brake service', 'minor-service' ],
		[ 'rebuild', 'Crash rebuild', 'collision-repair' ],
		[ 'paint', 'Panel beating & paint', 'panel-repaint' ],
		[ 'booth', 'Straight out of the booth', 'full-respray' ],
		[ 'ceramic', 'Waxed & ready for collection', 'ceramic-coating' ],
	];
	$h = '<div class="tj-clips">';
	foreach ( $clips as [ $clip, $label, $slug ] ) {
		if ( ! file_exists( get_stylesheet_directory() . '/assets/clips/' . $clip . '.mp4' ) ) {
			continue;
		}
		$p  = tj_product( $slug );
		$h .= '<a class="tj-clip" href="' . esc_url( $p ? $p->get_permalink() : '#' ) . '"><video src="' . esc_url( tj_clip_url( $clip ) ) . '" poster="' . esc_url( str_replace( '.mp4', '.webp', tj_clip_url( $clip ) ) ) . '" muted loop playsinline autoplay preload="none"></video><span>' . esc_html( $label ) . '</span></a>';
	}
	return $h . '</div>';
} );

// Instant estimate & quote builder: vehicle type × service × photos × add-ons × drop-off or towing.
// tj.js does the maths, the booking and the WhatsApp message.
add_shortcode( 'tj_estimator', function () {
	$est = tj_estimator_data();
	if ( ! $est['tiers'] || ! $est['sizes'] ) {
		return '';
	}
	$opt = fn( $v, $label ) => '<option value="' . esc_attr( $v ) . '">' . esc_html( $label ) . '</option>';
	ob_start();
	?>
	<form class="tj-est" data-tj-estimator novalidate>
		<ol class="tj-est__steps" aria-hidden="true"><li class="is-on">Vehicle</li><li>Service</li><li>Photos</li><li>Add-ons</li><li>Drop-off</li></ol>

		<fieldset class="tj-est__step" data-step="1">
			<legend><span>1</span> Vehicle type</legend>
			<div class="tj-est__cards tj-est__cards--5">
				<?php foreach ( $est['sizes'] as $slug => $name ) : ?>
					<label><input type="radio" name="size" value="<?php echo esc_attr( $slug ); ?>"<?php echo $slug === 'sedan' ? ' checked' : ''; ?>><strong><?php echo esc_html( $name ); ?></strong></label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="tj-est__step" data-step="2">
			<legend><span>2</span> Service category</legend>
			<div class="tj-est__cards tj-est__cards--5">
				<?php foreach ( $est['tiers'] as $key => $t ) : ?>
					<label><input type="radio" name="tier" value="<?php echo esc_attr( $key ); ?>"<?php echo $key === 'minor' ? ' checked' : ''; ?>><strong><?php echo esc_html( $t['name'] ); ?></strong><em><?php echo esc_html( $t['sub'] ); ?></em><b data-tj-tier-price="<?php echo esc_attr( $key ); ?>"></b><small><?php echo esc_html( $t['time'] ); ?></small></label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="tj-est__step" data-step="3">
			<legend><span>3</span> Photos of the damage <em>(optional)</em></legend>
			<label class="tj-drop" data-tj-drop>
				<input type="file" name="photos" accept="image/*" multiple data-tj-photos>
				<span class="tj-drop__icon" aria-hidden="true">⇪</span>
				<strong>Drop photos of scratches, dents or accident damage here</strong>
				<span>or tap to choose them. Clear photos in daylight, from a few steps back and close up.</span>
			</label>
			<div class="tj-drop__thumbs" data-tj-thumbs hidden></div>
			<p class="tj-small" data-tj-drop-note hidden>Your photos stay on your phone: a WhatsApp link can't carry them, so attach them in the chat after you tap "Send for assessment".</p>
		</fieldset>

		<fieldset class="tj-est__step" data-step="4">
			<legend><span>4</span> Add-ons</legend>
			<div class="tj-est__addons">
				<?php foreach ( $est['addons'] as $slug => $a ) : ?>
					<label data-tj-addon="<?php echo esc_attr( $slug ); ?>"><input type="checkbox" name="addon" value="<?php echo esc_attr( $slug ); ?>"><span><?php echo esc_html( $a['name'] ); ?></span><b data-tj-addon-price></b></label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="tj-est__step" data-step="5">
			<legend><span>5</span> Drop-off or towing?</legend>
			<div class="tj-est__grid">
				<label>How the car gets to us<select name="place"><?php foreach ( TJ_PLACES as $k => $v ) echo $opt( $k, $v ); ?></select></label>
				<label data-tj-area hidden>Pick-up area<select name="area"><?php foreach ( array_slice( TJ_AREAS, 1, null, true ) as $k => $v ) echo $opt( $k, $v ); ?></select></label>
			</div>
		</fieldset>

		<div class="tj-est__result" aria-live="polite">
			<div>
				<p class="tj-est__label">Your estimate</p>
				<p class="tj-est__total" data-tj-est-total>KSh 0</p>
				<p class="tj-est__time" data-tj-est-time></p>
				<p class="tj-est__summary" data-tj-est-summary></p>
				<p class="tj-small" data-tj-est-note></p>
			</div>
			<div class="tj-est__actions">
				<button type="button" class="wp-element-button" data-tj-est-book>Book a workshop slot</button>
				<a class="tj-wa-order tj-est__wa" data-tj-est-wa href="<?php echo esc_url( tj_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo TJ_WA_ICON; ?><span data-tj-est-wa-label>Get this quote on WhatsApp</span></a>
			</div>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Fleets, buses & trucks request: composes a WhatsApp message (nothing is stored on the site).
add_shortcode( 'tj_fleet_form', function () {
	$sel = fn( $name, array $opts ) => '<select name="' . $name . '">' . implode( '', array_map( fn( $o ) => '<option>' . esc_html( $o ) . '</option>', $opts ) ) . '</select>';
	ob_start();
	?>
	<form class="tj-est tj-fleet" data-tj-fleet>
		<div class="tj-est__grid">
			<label>Company / school / organisation<input type="text" name="company" autocomplete="organization" required></label>
			<label>Your name<input type="text" name="name" autocomplete="name" required></label>
			<label>Phone<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required></label>
			<label>Number of vehicles<input type="number" name="count" min="2" max="500" value="5" inputmode="numeric"></label>
			<label>Mostly<?php echo $sel( 'types', [ 'Saloons & pool cars', 'SUVs & 4x4s', 'Vans & pickups', 'Buses', 'Trucks', 'A mix' ] ); ?></label>
			<label>Service<?php echo $sel( 'service', [ 'Routine servicing', 'Accident & body repair', 'Repainting', 'Diagnostics & mechanical', 'Not sure: advise us' ] ); ?></label>
			<label>How often<?php echo $sel( 'often', [ 'Once (a one-off job)', 'Every month', 'Every quarter' ] ); ?></label>
			<label>Pick-up needed?<?php echo $sel( 'pickup', [ 'No, we drop off on Rabai Road', 'Yes, collect from our premises' ] ); ?></label>
		</div>
		<label class="tj-fleet__notes">Anything else (working hours, insurance jobs, service records)<textarea name="notes" rows="3"></textarea></label>
		<div class="tj-est__result">
			<p class="tj-small">We reply on WhatsApp with a per-vehicle price and a schedule that keeps your vehicles on the road.</p>
			<button type="submit" class="tj-wa-order tj-est__wa"><?php echo TJ_WA_ICON; ?>Send fleet request on WhatsApp</button>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Insurance claim centre: how a claim works with the garage, then the claim request form.
add_shortcode( 'tj_claim_guide', function () {
	$steps = [
		[ 'Report it', 'Tell your insurer about the accident and get a claim form. For anything more than a scrape, get a police abstract too.' ],
		[ 'Bring the car, or we tow it', 'Drive in to Rabai Road, or send us the location and we arrange towing to the garage.' ],
		[ 'We assess & estimate', 'We inspect the damage, take the photos and prepare the repair estimate your insurer or their assessor needs.' ],
		[ 'Approval', 'We liaise with the assessor and call you as soon as the repair is approved. You pay only the excess and anything your policy doesn\'t cover.' ],
		[ 'Repair & quality check', 'Panels, paint, airbags and modules done in-house, then the car is inspected and road-tested before release.' ],
	];
	$h = '<div class="tj-claim"><p class="tj-claim__lead">Insurers already send us cars like a Range Rover Sport that met a tree. Here is how a claim goes with TJ &amp; U.</p><ol class="tj-claim__steps">';
	foreach ( $steps as [ $t, $d ] ) {
		$h .= '<li><strong>' . esc_html( $t ) . '</strong><span>' . esc_html( $d ) . '</span></li>';
	}
	$h .= '</ol><div class="tj-claim__bring"><strong>Bring with you</strong><ul><li>Insurance claim form</li><li>Copy of the logbook and your ID</li><li>Driving licence of whoever was driving</li><li>Police abstract (for most accidents)</li></ul></div></div>';
	return $h;
} );
add_shortcode( 'tj_claim_form', function () {
	ob_start();
	?>
	<form class="tj-est tj-fleet" data-tj-claim>
		<h2 class="tj-claim__title">Start your claim repair</h2>
		<div class="tj-est__grid">
			<label>Your name<input type="text" name="name" autocomplete="name" required></label>
			<label>Phone<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required></label>
			<label>Vehicle make & model<input type="text" name="vehicle" placeholder="e.g. Mazda CX-5" required></label>
			<label>Registration<input type="text" name="plate" placeholder="e.g. KDA 123A"></label>
			<label>Insurance company<input type="text" name="insurer" placeholder="Your insurer"></label>
			<label>Is the car drivable?<select name="drivable"><option>Yes, I'll drive it in</option><option>No, I need towing</option></select></label>
		</div>
		<label class="tj-fleet__notes">What happened and what's damaged<textarea name="notes" rows="3" required></textarea></label>
		<div class="tj-est__result">
			<p class="tj-small">This opens WhatsApp with your details. Attach photos of the damage and the claim form in the chat.</p>
			<button type="submit" class="tj-wa-order tj-est__wa"><?php echo TJ_WA_ICON; ?>Send claim details on WhatsApp</button>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Details pop-up (filled in by tj.js) and the floating WhatsApp button.
add_action( 'wp_footer', function () {
	echo '<dialog id="tj-qv" class="tj-dialog tj-qv" aria-label="Service details"><form method="dialog"><button class="tj-dialog__close" aria-label="Close">×</button></form><div data-tj-qv-body></div></dialog>';
	echo '<a class="tj-wa-float" href="' . esc_url( tj_wa_link( 'Hi TJ&U, I\'d like an estimate for my car:' ) ) . '" target="_blank" rel="noopener" aria-label="Chat with TJ & U Auto Garage on WhatsApp">' . TJ_WA_ICON . '</a>';
} );

/* -------------------------------------------------------------------------
 * Cart (the booking), checkout, confirmation
 * ---------------------------------------------------------------------- */

function tj_cart_note_html() {
	return '<div class="tj-cart-note"><strong>Next:</strong> choose garage drop-off or towing / pick-up, the date and a drop-off time. Nothing is paid online: you pay when you collect.</div>';
}
function tj_wa_cart_html() {
	return '<button type="button" class="tj-wa-cart" data-tj-wa-cart>' . TJ_WA_ICON . 'Send booking to TJ & U on WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => tj_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . tj_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', tj_cart_note_html() . '$1', $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="tj-wa-cart-wrap">' . tj_wa_cart_html() . '</div>' );

// Booking words on the cart and checkout buttons.
add_filter( 'render_block_data', function ( $block ) {
	$labels = [
		'woocommerce/checkout-actions-block'          => [ 'placeOrderButtonLabel', 'Confirm my booking' ],
		'woocommerce/proceed-to-checkout-block'       => [ 'buttonLabel', 'Choose date & time' ],
		'woocommerce/mini-cart-title-label-block'     => [ 'label', 'Your booking' ],
		'woocommerce/mini-cart-checkout-button-block' => [ 'checkoutButtonLabel', 'Book now' ],
		'woocommerce/mini-cart-cart-button-block'     => [ 'cartButtonLabel', 'View booking' ],
	];
	if ( isset( $labels[ $block['blockName'] ] ) ) {
		[ $attr, $text ]          = $labels[ $block['blockName'] ];
		$block['attrs'][ $attr ] = $text;
	}
	// Checkout steps in booking words: 1 you, 2 your car & appointment, 3 payment.
	$steps = [
		'woocommerce/checkout-contact-information-block'    => [ 'Your contact details', 'We send your booking confirmation here.' ],
		'woocommerce/checkout-billing-address-block'        => [ 'Your name & pick-up address', 'The address is only needed if we tow or collect your car.' ],
		'woocommerce/checkout-additional-information-block' => [ 'Your vehicle & appointment', 'Make, model and registration plate, drop-off or towing, and when.' ],
		'woocommerce/checkout-payment-block'                => [ 'How you\'ll pay', 'Nothing is paid online.' ],
	];
	if ( isset( $steps[ $block['blockName'] ] ) ) {
		[ $block['attrs']['title'], $block['attrs']['description'] ] = $steps[ $block['blockName'] ];
	}
	// The car and the appointment come before payment.
	if ( $block['blockName'] === 'woocommerce/checkout-fields-block' && ! empty( $block['innerBlocks'] ) ) {
		$names = array_column( $block['innerBlocks'], 'blockName' );
		$info  = array_search( 'woocommerce/checkout-additional-information-block', $names, true );
		$pay   = array_search( 'woocommerce/checkout-payment-block', $names, true );
		if ( $info !== false && $pay !== false && $info > $pay ) {
			$moved = array_splice( $block['innerBlocks'], $info, 1 );
			array_splice( $block['innerBlocks'], $pay, 0, $moved );
		}
	}
	return $block;
} );

// Add-ons are shown as "Popular add-ons" next to the button, so skip WooCommerce's own upsell row.
add_action( 'init', fn() => remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 ) );

// Vehicle-type pages: a readable breadcrumb instead of "Product Vehicle type".
add_filter( 'woocommerce_get_breadcrumb', function ( $crumbs ) {
	if ( tj_current_vehicle() ) {
		foreach ( $crumbs as $i => $c ) {
			if ( str_contains( (string) $c[0], 'Vehicle type' ) ) {
				$crumbs[ $i ] = [ 'Prices by vehicle', home_url( '/#vehicles' ) ];
			}
		}
	}
	return $crumbs;
} );

/** The next three weeks as booking dates, Sundays left out (closed): Y-m-d => "Thu 8 Oct". */
function tj_booking_dates() {
	$out = [];
	$day = new DateTime( 'tomorrow', wp_timezone() );
	for ( $i = 0; $i < 21; $i++ ) {
		$n = $day->format( 'N' );
		if ( $n !== '7' ) {
			$out[ $day->format( 'Y-m-d' ) ] = $day->format( 'D j M' ) . ( $n === '6' ? ' (closes 3 pm)' : '' );
		}
		$day->modify( '+1 day' );
	}
	return $out;
}

// What the garage needs to know: field => [ label, short label, options (null = text), required ].
function tj_checkout_fields() {
	return [
		'tj/vehicle' => [ 'Vehicle make & model (e.g. Toyota Premio)', 'Vehicle', null, true ],
		'tj/plate'   => [ 'Registration plate (e.g. KDA 123A)', 'Registration', null, true ],
		'tj/place'   => [ 'Drop-off at the garage or towing / pick-up?', 'Drop-off', TJ_PLACES, true ],
		'tj/area'    => [ 'Pick-up area (towing / pick-up only)', 'Pick-up area', TJ_AREAS, true ],
		'tj/date'    => [ 'Preferred date', 'Date', tj_booking_dates(), true ],
		'tj/time'    => [ 'Drop-off / pick-up time', 'Time', TJ_SLOTS, true ],
		'tj/notes'   => [ 'Special notes for the mechanic (noises, warning lights, damage)', 'Notes', null, false ],
	];
}
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	foreach ( tj_checkout_fields() as $id => [ $label, , $options, $required ] ) {
		$field = [ 'id' => $id, 'label' => $label, 'location' => 'order', 'type' => $options ? 'select' : 'text', 'required' => $required ];
		if ( $options ) {
			$field['options'] = array_map( fn( $v, $l ) => [ 'value' => (string) $v, 'label' => $l ], array_keys( $options ), $options );
		}
		woocommerce_register_additional_checkout_field( $field );
	}
} );

function tj_booking_code( WC_Order $order ) {
	return 'TJ-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
/** Booking details from the checkout fields, as short label => readable value. */
function tj_booking_details( WC_Order $order ) {
	$out = [];
	foreach ( tj_checkout_fields() as $key => [ , $label, $options ] ) {
		$value = (string) $order->get_meta( '_wc_other/' . $key );
		if ( $value !== '' && ! ( $key === 'tj/area' && $value === 'none' ) ) {
			$out[ $label ] = $options[ $value ] ?? $value;
		}
	}
	return $out;
}
function tj_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi TJ&U, I just booked online (' . tj_booking_code( $order ) . '):' ];
	foreach ( $order->get_items() as $item ) {
		$lines[] = '• ' . html_entity_decode( $item->get_name(), ENT_QUOTES ) . ( $item->get_quantity() > 1 ? ' × ' . $item->get_quantity() : '' ) . ' – ' . tj_money( $item->get_total() );
	}
	$lines[] = 'Total: ' . tj_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	foreach ( tj_booking_details( $order ) as $label => $value ) {
		$lines[] = $label . ': ' . $value;
	}
	$address = trim( implode( ', ', array_filter( [ $order->get_billing_address_1(), $order->get_billing_city() ] ) ) );
	if ( $address ) {
		$lines[] = 'Pick-up address: ' . $address;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return tj_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) { // phpcs:ignore
		return $content;
	}
	$d     = tj_booking_details( $order );
	$when  = implode( ' · ', array_filter( [ $d['Date'] ?? '', $d['Time'] ?? '', $d['Drop-off'] ?? '' ] ) );
	$pickup = ( (string) $order->get_meta( '_wc_other/tj/place' ) ) === 'pickup';
	return $content . '<div class="tj-thanks"><p class="tj-thanks__code">Booking number <strong>' . esc_html( tj_booking_code( $order ) ) . '</strong></p>' . ( $when ? '<p class="tj-thanks__when">' . esc_html( $when ) . '</p>' : '' ) . '<ol><li>We call you shortly to confirm the slot' . ( $pickup ? ' and the towing / pick-up' : '' ) . '.</li><li>' . ( $pickup ? 'We collect your car (or tow it) and bring it to the garage.' : 'Drop your car at our garage on Rabai Road, Buruburu, near the Rubis petrol station (<a href="' . esc_url( TJ_MAPS ) . '" target="_blank" rel="noopener">map</a>).' ) . '</li><li>We check the car before release; then you inspect it and pay by M-Pesa or cash.</li></ol><a class="wp-element-button tj-wa-btn" href="' . esc_attr( tj_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . TJ_WA_ICON . 'Send booking to TJ & U on WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Booking number:</strong> ' . esc_html( tj_booking_code( $order ) ) . '</p>';
} );

// Staff edit the card badges, the facts, what's included and the workshop clip on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_tj_badge', 'label' => 'Card label', 'description' => 'Small label above the name, e.g. "Most booked".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_tj_perk', 'label' => 'Card badge', 'description' => 'One benefit shown on the card, e.g. "Genuine parts".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_tj_perks', 'label' => 'Benefit badges', 'description' => 'Shown on the service page, separated by |, e.g. "Oil & filter | Brakes checked".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_tj_time', 'label' => 'Time', 'description' => 'e.g. "2–3 hours".', 'desc_tip' => true ] );
	woocommerce_wp_select( [ 'id' => '_tj_clip', 'label' => 'Workshop clip', 'options' => [ '' => 'None', 'service' => 'Oil & brake service', 'rebuild' => 'Crash rebuild', 'paint' => 'Panel beating & paint', 'booth' => 'Paint booth', 'ceramic' => 'Ceramic coating', 'interior' => 'Upholstery' ] ] );
	woocommerce_wp_checkbox( [ 'id' => '_tj_quote', 'label' => 'Price after inspection', 'description' => 'Shows the price as indicative and the button as "Book an inspection".' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_tj_specs', 'label' => 'Good to know', 'rows' => 5, 'description' => 'One per line, as "Label: value". The first four also show next to the price.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_tj_included', 'label' => 'What\'s included', 'rows' => 8, 'description' => 'One item per line.' ] );
	echo '<p class="form-field"><em>Prices by vehicle: the "Vehicle type" attribute makes the variations; set each variation\'s price under Variations. "Popular add-ons" = Linked Products → Upsells.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_tj_badge', '_tj_perk', '_tj_perks', '_tj_time', '_tj_clip' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
	$product->update_meta_data( '_tj_quote', isset( $_POST['_tj_quote'] ) ? 'yes' : 'no' ); // phpcs:ignore
	foreach ( [ '_tj_specs', '_tj_included' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode or county. The address only matters when the garage tows or collects the car.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode']  = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['state']     = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_2'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_1'] = [ 'label' => 'Pick-up address (only for towing / pick-up)', 'required' => false ];
	$locale['KE']['city']      = [ 'label' => 'Area / estate', 'required' => false ];
	$locale['KE']['phone']     = [ 'required' => true ];
	return $locale;
} );

// Booking words for WooCommerce's shop words.
add_filter( 'gettext', function ( $text, $original, $domain ) {
	if ( $domain !== 'woocommerce' ) {
		return $text;
	}
	return [
		'Related products'  => 'You may also like',
		'Continue shopping' => 'Keep browsing services',
		'Order received'    => 'Booking received',
		'Thank you. Your order has been received.' => 'Thank you. Your booking has been received.',
	][ $original ] ?? $text;
}, 10, 3 );
add_filter( 'ngettext', function ( $text, $single, $plural, $number, $domain ) {
	return $domain === 'woocommerce' && $single === '%s has been added to your cart.' ? '%s has been added to your booking.' : $text;
}, 10, 5 );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#18181B\">\n";
} );

// Shortcode blocks: run the shortcode as is. The block's automatic paragraphs break the
// estimator's and reviews' grids with stray <p> and <br> tags.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	return ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre;
}, 10, 2 );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src|poster)="/(?!/)#', '$1="' . $home, $content );
} );

