( function () {
	const cfg = window.TJ || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const waUrl = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );
	const store = {
		get: ( k ) => {
			try {
				return JSON.parse( sessionStorage.getItem( k ) || 'null' );
			} catch ( e ) {
				return null;
			}
		},
		set: ( k, v ) => {
			try {
				sessionStorage.setItem( k, JSON.stringify( v ) );
			} catch ( e ) {}
		},
	};

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.tj-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'tj-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'tj-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	const addedMsg = () => '✓ Added to your booking · <a href="' + esc( cfg.checkout || '/checkout/' ) + '">Choose date &amp; time</a>';
	document.body.addEventListener( 'wc-blocks_added_to_cart', ( e ) => {
		if ( ! ( e.detail && e.detail.tjQuiet ) ) toast( addedMsg() );
	} );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( addedMsg() ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store: iStore } = await import( '@wordpress/interactivity' );
			const wc = iStore( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function addItem( id ) {
		if ( ! nonce ) await getCart();
		const res = await fetch( cfg.store + 'cart/add-item', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', Nonce: nonce },
			body: JSON.stringify( { id: Number( id ), quantity: 1 } ),
		} );
		const cart = await res.json();
		if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
		return cart;
	}
	// ids: products or chosen variations. Opens the booking drawer once everything is in.
	async function addToCart( ids, btn, quiet ) {
		if ( btn ) btn.disabled = true;
		try {
			let cart;
			for ( const id of [].concat( ids ) ) cart = await addItem( id );
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true, detail: { tjQuiet: !! quiet } } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
			return true;
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your booking. Please try again.' ) );
			return false;
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-tj-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.tjAdd, b );
	} );

	/* WhatsApp booking from the cart ------------------------------------- */
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		return '• ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ( it.quantity > 1 ? ' × ' + it.quantity : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-tj-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your booking is empty.' );
				return;
			}
			const where = store.get( 'tj-where' );
			const lines = [ 'Hi TJ&U, I\'d like to book:' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Total: ' + fmt( money( cart.totals.total_price, cart.totals ) ) );
			if ( where ) lines.push( 'Drop-off: ' + where.place + ( where.area ? ', ' + where.area : '' ) );
			lines.push( 'Vehicle (make, model, registration): ', 'Preferred date & time: ', 'Notes: ' );
			const url = waUrl( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your booking. Please try again.' );
		}
	} );

	/* Service page: option buttons ------------------------------------- */
	// Turns WooCommerce's option drop-downs into buttons (the drop-downs stay in the form, hidden, so
	// WooCommerce still swaps the price). Vehicle classes show their price.
	function variationPrices( form ) {
		try {
			return JSON.parse( form.dataset.product_variations || '[]' );
		} catch ( e ) {
			return [];
		}
	}
	function initOptions() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.tjSw ) return;
			sel.dataset.tjSw = '1';
			const form = sel.closest( 'form' );
			const wrap = document.createElement( 'div' );
			wrap.setAttribute( 'role', 'radiogroup' );
			wrap.className = 'tj-sw';
			const opts = Array.from( sel.options ).filter( ( o ) => o.value );
			wrap.innerHTML = opts.map( ( o ) => '<button type="button" role="radio" aria-checked="false" data-v="' + esc( o.value ) + '"><span>' + esc( o.text ) + '</span></button>' ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'tj-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				const on = b.dataset.v === sel.value;
				b.classList.toggle( 'is-on', on );
				b.setAttribute( 'aria-checked', on ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
				updateWaProduct( form );
			} );
			// Vehicle-class buttons show the price for that class (the lowest, if there's a second choice).
			if ( sel.name === 'attribute_pa_vehicle' ) {
				const vars = variationPrices( form );
				$$( 'button', wrap ).forEach( ( b ) => {
					const prices = vars.filter( ( v ) => v.attributes && v.attributes.attribute_pa_vehicle === b.dataset.v ).map( ( v ) => v.display_price );
					if ( prices.length ) b.insertAdjacentHTML( 'beforeend', '<small>' + ( prices.length > 1 ? 'from ' : '' ) + esc( fmt( Math.min( ...prices ) ) ) + '</small>' );
				} );
			}
			paint();
			updateWaProduct( form );
		} );
		// Hide WooCommerce's "Clear" link: an option is always chosen.
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
	}
	// The service page's WhatsApp button names the options the customer picked.
	function updateWaProduct( form ) {
		const a = document.querySelector( '[data-tj-wa-product]' );
		if ( ! a || ! form ) return;
		const picked = $$( 'select[name^="attribute_"]', form ).map( ( s ) => ( s.value ? s.options[ s.selectedIndex ].text : '' ) ).filter( Boolean ).join( ', ' );
		const msg = 'Hi TJ&U, I\'d like a quote for: ' + a.dataset.tjWaProduct + ( picked ? ' (' + picked + ')' : ' (' + a.dataset.tjWaPrice + ')' ) + '. ' + a.dataset.tjWaUrl;
		a.href = waUrl( msg );
	}

	/* Details & video pop-up --------------------------------------------- */
	const choiceNames = ( p ) => ( p.attributes || [] ).filter( ( a ) => a.has_variations ).map( ( a ) => plain( a.name ).toLowerCase() );
	const QV_MAX = 8;
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-tj-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'tj-qv' );
		const body = dlg && dlg.querySelector( '[data-tj-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="tj-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.tjQv ) ).json();
			const clip = b.dataset.tjClip;
			const video = clip ? '<video src="' + esc( clip ) + '" muted loop playsinline autoplay></video>' : '';
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '"' + ( i || clip ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 || clip ? '<div class="tj-qv__thumbs">' + ( clip ? '<button type="button" class="tj-qv__pov" data-tj-qv-img="v">▶ POV</button>' : '' ) + p.images.map( ( im, i ) => '<button type="button" data-tj-qv-img="' + i + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const cats = p.categories && p.categories[ 0 ] ? plain( p.categories[ 0 ].name ) : '';
			const termName = ( attrName, val ) => {
				const attr = ( p.attributes || [] ).find( ( a ) => a.name === attrName || a.taxonomy === attrName );
				const term = attr && ( attr.terms || [] ).find( ( t ) => t.slug === val || t.name === val );
				return term ? plain( term.name ) : val;
			};
			let choose = '';
			let buy;
			if ( ! p.is_purchasable || ! p.is_in_stock ) {
				buy = '<a class="wp-element-button" href="' + esc( p.permalink ) + '">View service</a>';
			} else if ( p.variations && p.variations.length && p.variations.length <= QV_MAX ) {
				choose = '<p class="tj-qv__label">' + esc( choiceNames( p ).join( ' & ' ) ) + ': <strong data-tj-qv-picked></strong></p><div class="tj-sw">' + p.variations.map( ( v, i ) => {
					const label = ( v.attributes || [] ).map( ( a ) => termName( a.name, a.value ) ).join( ' · ' );
					return '<button type="button" data-tj-qv-var="' + v.id + '" data-label="' + esc( label ) + '"' + ( i ? '' : ' class="is-on"' ) + '><span>' + esc( label ) + '</span></button>';
				} ).join( '' ) + '</div>';
				buy = '<button type="button" class="wp-element-button" data-tj-add="' + p.variations[ 0 ].id + '" data-tj-qv-buy>Select package</button>';
			} else if ( p.type === 'variable' ) {
				buy = '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose ' + esc( choiceNames( p )[ 0 ] || 'options' ) + '</a>';
			} else {
				buy = '<button type="button" class="wp-element-button" data-tj-add="' + p.id + '">Select package</button>';
			}
			body.innerHTML = '<div class="tj-qv__grid"><div class="tj-qv__media"><div class="tj-qv__main">' + video + imgs + '</div>' + thumbs + '</div>' +
				'<div class="tj-qv__info">' + ( cats ? '<p class="tj-eyebrow">' + esc( cats ) + '</p>' : '' ) + '<h2>' + p.name + '</h2><div class="tj-qv__price">' + p.price_html + '</div>' +
				'<div class="tj-qv__desc">' + ( p.short_description || '' ) + '</div>' + choose +
				'<div class="tj-qv__actions">' + buy + '<a class="tj-link" href="' + esc( p.permalink ) + '">What\'s included →</a></div></div></div>';
			const first = body.querySelector( '[data-tj-qv-var]' );
			if ( first ) pickQvVariation( first );
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this service. Please try again.</p>';
		}
	} );
	// Variation price: the Store API lists variations without it, so fetch the chosen one.
	async function pickQvVariation( btn ) {
		const box = btn.closest( '[data-tj-qv-body]' );
		$$( '[data-tj-qv-var]', box ).forEach( ( b ) => b.classList.toggle( 'is-on', b === btn ) );
		const picked = box.querySelector( '[data-tj-qv-picked]' );
		if ( picked ) picked.textContent = btn.dataset.label;
		const buy = box.querySelector( '[data-tj-qv-buy]' );
		if ( buy ) buy.dataset.tjAdd = btn.dataset.tjQvVar;
		try {
			const v = await ( await fetch( cfg.store + 'products/' + btn.dataset.tjQvVar ) ).json();
			// A slower reply for an earlier pick must not overwrite the current one.
			if ( ! btn.classList.contains( 'is-on' ) ) return;
			const price = box.querySelector( '.tj-qv__price' );
			if ( price && v.price_html ) price.innerHTML = v.price_html;
		} catch ( e ) {}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-tj-qv-var]' );
		if ( b ) pickQvVariation( b );
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-tj-qv-img]' );
		if ( ! t ) return;
		const media = t.closest( '.tj-qv__media' );
		media.querySelectorAll( '.tj-qv__main img' ).forEach( ( im, i ) => ( im.hidden = String( i ) !== t.dataset.tjQvImg ) );
		const v = media.querySelector( '.tj-qv__main video' );
		if ( v ) v.hidden = t.dataset.tjQvImg !== 'v';
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.tj-dialog' ) ) e.target.close();
		// Close the call / WhatsApp menu when clicking elsewhere.
		$$( 'details.tj-contact[open]' ).forEach( ( d ) => {
			if ( ! d.contains( e.target ) ) d.open = false;
		} );
	} );
	// Stop the pop-up video when it closes.
	document.addEventListener( 'close', ( e ) => {
		if ( e.target.id === 'tj-qv' ) e.target.querySelector( '[data-tj-qv-body]' ).innerHTML = '';
	}, true );

	/* Instant estimate & quote builder ----------------------------------- */
	// A part is a fixed price ({ id, price }) or priced per vehicle type ({ by: { type: { id, price } } }).
	const partFor = ( part, size ) => ( part.by ? part.by[ size ] : part );
	// Prices round to the nearest KSh 500, the way the garage quotes.
	const round500 = ( n ) => Math.round( n / 500 ) * 500;
	const range = ( lo, hi ) => ( hi > lo ? fmt( lo ) + ' – ' + fmt( hi ).replace( 'KSh ', '' ) : fmt( lo ) );
	function estimate( form ) {
		const est = cfg.est;
		const f = new FormData( form );
		const size = f.get( 'size' );
		const tier = est.tiers[ f.get( 'tier' ) ];
		const items = [];
		let base = 0;
		let extras = 0;
		const inTier = new Set();
		tier.parts.forEach( ( part ) => {
			const hit = partFor( part, size );
			inTier.add( part.slug );
			if ( hit ) {
				items.push( { id: hit.id, name: part.name, price: hit.price } );
				base += hit.price;
			}
		} );
		f.getAll( 'addon' ).forEach( ( slug ) => {
			const a = est.addons[ slug ];
			const hit = a && ! inTier.has( slug ) && partFor( a, size );
			if ( hit ) {
				items.push( { id: hit.id, name: a.name, price: hit.price } );
				extras += hit.price;
			}
		} );
		const placeKey = f.get( 'place' );
		const pickup = placeKey === 'pickup';
		const lo = base + extras;
		const hi = round500( base * ( tier.spread || 1 ) ) + extras;
		return { size, sizeName: est.sizes[ size ], tierName: tier.name, time: tier.time, quote: tier.quote, inTier, items, total: lo, lo, hi, placeKey, place: est.places[ placeKey ], areaKey: pickup ? f.get( 'area' ) : 'none', area: pickup ? est.areas[ f.get( 'area' ) ] : '', pickup };
	}
	function initEstimator() {
		if ( ! cfg.est ) return;
		$$( '[data-tj-estimator]' ).forEach( ( form ) => {
			const out = form.querySelector( '[data-tj-est-total]' );
			const time = form.querySelector( '[data-tj-est-time]' );
			const sum = form.querySelector( '[data-tj-est-summary]' );
			const note = form.querySelector( '[data-tj-est-note]' );
			const wa = form.querySelector( '[data-tj-est-wa]' );
			const waLabel = form.querySelector( '[data-tj-est-wa-label]' );
			const book = form.querySelector( '[data-tj-est-book]' );
			const area = form.querySelector( '[data-tj-area]' );
			const steps = $$( '.tj-est__steps li', form );
			const photos = initPhotos( form, () => update() );
			const update = () => {
				const r = estimate( form );
				$$( '.tj-est__cards label, .tj-est__addons label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				// Each service card shows its price range for the chosen vehicle.
				$$( '[data-tj-tier-price]', form ).forEach( ( el ) => {
					const t = cfg.est.tiers[ el.dataset.tjTierPrice ];
					const lo = t.parts.reduce( ( s, p ) => s + ( partFor( p, r.size ) ? partFor( p, r.size ).price : 0 ), 0 );
					el.textContent = range( lo, round500( lo * ( t.spread || 1 ) ) );
				} );
				// Add-on prices follow the vehicle; one already in the service is shown as included.
				$$( '[data-tj-addon]', form ).forEach( ( l ) => {
					const slug = l.dataset.tjAddon;
					const hit = partFor( cfg.est.addons[ slug ], r.size );
					const included = r.inTier.has( slug );
					l.classList.toggle( 'is-included', included );
					l.querySelector( 'input' ).disabled = included;
					l.querySelector( '[data-tj-addon-price]' ).textContent = included ? 'Included' : hit ? '+ ' + fmt( hit.price ) : '';
				} );
				area.hidden = ! r.pickup;
				out.textContent = range( r.lo, r.hi );
				time.textContent = 'About ' + r.time + ' at the garage';
				sum.textContent = r.sizeName + ' · ' + r.items.map( ( i ) => i.name ).join( ' + ' );
				note.textContent = ( r.hi > r.lo ? 'The usual range for this work; we confirm the exact price after inspecting the car. ' : '' ) +
					( r.pickup
						? ( r.areaKey === 'other' ? 'Towing / pick-up: we quote the fee when we confirm.' : 'Towing / pick-up from ' + r.area + ' (fee quoted when we confirm).' )
						: 'Drop-off on Rabai Road, Buruburu: Mon–Fri 7:30–5:30, Sat 8–3.' ) +
					' Pay when you collect.';
				const n = photos.count();
				waLabel.textContent = n ? 'Send for assessment (' + n + ' photo' + ( n > 1 ? 's' : '' ) + ')' : 'Get this quote on WhatsApp';
				wa.href = waUrl( [
					'Hi TJ&U, I\'d like ' + ( n ? 'an assessment' : 'a quote' ) + ':',
					'• Vehicle: ' + r.sizeName,
					...r.items.map( ( i ) => '• ' + i.name + ' – ' + fmt( i.price ) ),
					'Website estimate: ' + range( r.lo, r.hi ) + ' (' + r.time + ')',
					'Drop-off: ' + r.place + ( r.area ? ', ' + r.area : '' ),
					...( n ? [ 'I\'m attaching ' + n + ' photo' + ( n > 1 ? 's' : '' ) + ' of the damage.' ] : [] ),
					'Make, model & registration: ',
					'Preferred date: ',
				].join( '\n' ) );
				store.set( 'tj-where', { place: r.place, area: r.area, placeKey: r.placeKey, areaKey: r.areaKey } );
			};
			form.addEventListener( 'input', update );
			form.addEventListener( 'change', update );
			form.addEventListener( 'submit', ( e ) => e.preventDefault() );
			wa.addEventListener( 'click', () => {
				if ( photos.count() ) toast( 'WhatsApp is opening. Attach your ' + photos.count() + ' photo' + ( photos.count() > 1 ? 's' : '' ) + ' in the chat, then send.' );
			} );
			book.addEventListener( 'click', async () => {
				const r = estimate( form );
				if ( ! r.items.length ) return;
				const label = book.textContent;
				book.textContent = 'Adding…';
				const ok = await addToCart( r.items.map( ( i ) => i.id ), book, true );
				book.textContent = label;
				if ( ok ) toast( '✓ ' + esc( r.tierName ) + ' added for your ' + esc( r.sizeName ) + ' · <a href="' + esc( cfg.checkout ) + '">Choose date &amp; time</a>' );
			} );
			// Light up the step the customer is working on.
			form.addEventListener( 'focusin', ( e ) => {
				const fs = e.target.closest( '[data-step]' );
				if ( fs ) steps.forEach( ( li, i ) => li.classList.toggle( 'is-on', i < Number( fs.dataset.step ) ) );
			} );
			update();
		} );
	}

	/* Damage photos: previewed on the page only. A wa.me link can only carry text, so nothing is uploaded;
	   the customer attaches the photos in the WhatsApp chat. */
	function initPhotos( form, onChange ) {
		const input = form.querySelector( '[data-tj-photos]' );
		const drop = form.querySelector( '[data-tj-drop]' );
		const thumbs = form.querySelector( '[data-tj-thumbs]' );
		const hint = form.querySelector( '[data-tj-drop-note]' );
		let files = [];
		if ( ! input ) return { count: () => 0 };
		const paint = () => {
			thumbs.innerHTML = files.map( ( f, i ) => '<figure><img src="' + esc( f.url ) + '" alt=""><button type="button" data-tj-photo-x="' + i + '" aria-label="Remove ' + esc( f.name ) + '">×</button></figure>' ).join( '' );
			thumbs.hidden = hint.hidden = ! files.length;
			onChange();
		};
		const add = ( list ) => {
			const imgs = Array.from( list || [] ).filter( ( f ) => /^image\//.test( f.type ) ).slice( 0, 8 - files.length );
			imgs.forEach( ( f ) => files.push( { name: f.name, url: URL.createObjectURL( f ) } ) );
			if ( imgs.length ) toast( '✓ ' + imgs.length + ' photo' + ( imgs.length > 1 ? 's' : '' ) + ' ready. Attach ' + ( imgs.length > 1 ? 'them' : 'it' ) + ' in WhatsApp when you send for assessment.' );
			paint();
		};
		input.addEventListener( 'change', ( e ) => {
			e.stopPropagation();
			add( input.files );
			input.value = '';
		} );
		[ 'dragenter', 'dragover' ].forEach( ( t ) => drop.addEventListener( t, ( e ) => {
			e.preventDefault();
			drop.classList.add( 'is-over' );
		} ) );
		[ 'dragleave', 'drop' ].forEach( ( t ) => drop.addEventListener( t, () => drop.classList.remove( 'is-over' ) ) );
		drop.addEventListener( 'drop', ( e ) => {
			e.preventDefault();
			add( e.dataTransfer && e.dataTransfer.files );
		} );
		thumbs.addEventListener( 'click', ( e ) => {
			const x = e.target.closest( '[data-tj-photo-x]' );
			if ( ! x ) return;
			const [ gone ] = files.splice( Number( x.dataset.tjPhotoX ), 1 );
			URL.revokeObjectURL( gone.url );
			paint();
		} );
		return { count: () => files.length };
	}

	/* Checkout: carry drop-off / pick-up chosen in the customizer -------- */
	function prefillCheckout() {
		const where = store.get( 'tj-where' );
		const data = window.wp && window.wp.data;
		if ( ! where || ! data || ! document.querySelector( '.wp-block-woocommerce-checkout' ) ) return;
		let tries = 0;
		const timer = setInterval( () => {
			const checkout = data.dispatch( 'wc/store/checkout' );
			if ( ( checkout && checkout.setAdditionalFields ) || ++tries > 20 ) {
				clearInterval( timer );
				if ( checkout && checkout.setAdditionalFields ) {
					const current = ( data.select( 'wc/store/checkout' ).getAdditionalFields && data.select( 'wc/store/checkout' ).getAdditionalFields() ) || {};
					checkout.setAdditionalFields( { ...current, 'tj/place': current[ 'tj/place' ] || where.placeKey, 'tj/area': current[ 'tj/area' ] || where.areaKey } );
				}
			}
		}, 300 );
	}

	/* Before / after sliders and their tabs ------------------------------ */
	function initBeforeAfter() {
		$$( '[data-tj-ba]' ).forEach( ( fig ) => {
			const range = fig.querySelector( 'input[type=range]' );
			const set = () => fig.style.setProperty( '--pos', range.value + '%' );
			range.addEventListener( 'input', set );
			set();
		} );
		document.addEventListener( 'click', ( e ) => {
			const tab = e.target.closest( '[data-tj-ba-tab]' );
			if ( ! tab ) return;
			const wrap = tab.closest( '.tj-ba-wrap' );
			$$( '[data-tj-ba-tab]', wrap ).forEach( ( t ) => {
				const on = t === tab;
				t.classList.toggle( 'is-on', on );
				t.setAttribute( 'aria-selected', on ? 'true' : 'false' );
			} );
			$$( '[data-tj-ba-pane]', wrap ).forEach( ( p ) => ( p.hidden = p.dataset.tjBaPane !== tab.dataset.tjBaTab ) );
		} );
	}

	/* Studio clips: play only while on screen ---------------------------- */
	function initClips() {
		const vids = $$( '.tj-clip video, .tj-pdp-clip video' );
		if ( ! vids.length ) return;
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			vids.forEach( ( v ) => {
				v.removeAttribute( 'autoplay' );
				v.pause();
			} );
			return;
		}
		if ( ! ( 'IntersectionObserver' in window ) ) return;
		const io = new IntersectionObserver( ( entries ) => entries.forEach( ( en ) => {
			if ( en.isIntersecting ) en.target.play().catch( () => {} );
			else en.target.pause();
		} ), { rootMargin: '120px' } );
		vids.forEach( ( v ) => io.observe( v ) );
	}

	/* Fleet request -------------------------------------------------------- */
	function initFleet() {
		$$( '[data-tj-fleet]' ).forEach( ( form ) => {
			form.addEventListener( 'submit', ( e ) => {
				e.preventDefault();
				if ( ! form.reportValidity() ) return;
				const f = new FormData( form );
				const lines = [
					'Hi TJ&U, fleet request:',
					'• Company: ' + f.get( 'company' ),
					'• Vehicles: ' + f.get( 'count' ) + ' (' + f.get( 'types' ) + ')',
					'• Service: ' + f.get( 'service' ),
					'• How often: ' + f.get( 'often' ),
					'• Pick-up: ' + f.get( 'pickup' ),
				];
				if ( String( f.get( 'notes' ) ).trim() ) lines.push( '• Notes: ' + String( f.get( 'notes' ) ).trim() );
				lines.push( 'Contact: ' + f.get( 'name' ) + ', ' + f.get( 'phone' ) );
				window.open( waUrl( lines.join( '\n' ) ), '_blank', 'noopener' );
			} );
		} );
	}

	/* Insurance claim request ------------------------------------------- */
	function initClaim() {
		$$( '[data-tj-claim]' ).forEach( ( form ) => {
			form.addEventListener( 'submit', ( e ) => {
				e.preventDefault();
				if ( ! form.reportValidity() ) return;
				const f = new FormData( form );
				const lines = [
					'Hi TJ&U, I\'d like to start an insurance claim repair:',
					'• Vehicle: ' + f.get( 'vehicle' ) + ( String( f.get( 'plate' ) ).trim() ? ', ' + f.get( 'plate' ) : '' ),
					'• Insurer: ' + ( String( f.get( 'insurer' ) ).trim() || 'not given' ),
					'• Drivable: ' + f.get( 'drivable' ),
					'• What happened: ' + String( f.get( 'notes' ) ).trim(),
					'Contact: ' + f.get( 'name' ) + ', ' + f.get( 'phone' ),
					'(Attaching photos of the damage and the claim form.)',
				];
				window.open( waUrl( lines.join( '\n' ) ), '_blank', 'noopener' );
				toast( 'WhatsApp is opening. Attach photos of the damage and your claim form in the chat.' );
			} );
		} );
	}

	function init() {
		initOptions();
		initEstimator();
		initBeforeAfter();
		initClips();
		initFleet();
		initClaim();
		prefillCheckout();
		// The mini cart and checkout re-render client-side; keep the option buttons in place.
		new MutationObserver( () => initOptions() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
